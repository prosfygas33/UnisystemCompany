package com.example.Unisystems.model;

public enum Status {
    ACTIVE,
    INACTIVE
}
