package com.example.Unisystems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnisystemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
